#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <assert.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/des.h>
#include <openssl/sha.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>

#define KEY_LENGTH  2048
#define PUB_EXP     3
#define PRINT_KEYS
#define WRITE_TO_FILE

void handleErrors(void)
{
    ERR_print_errors_fp(stderr);
    abort();
}

void genRanKey(char alp[], char beta[], int a, int b) {
    char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        
    char* KS = (char*)malloc((a+1)*sizeof(char));
    srand(time(0));
    for(int j = 0; j < a; j++) {
        KS[j] = charset[rand() % 62];
    }
    KS[a] = '\0';
    strcpy(alp, KS);

    char* IV = (char*)malloc((b+1)*sizeof(char));
    for(int j = 0; j < b; j++) {
        IV[j] = charset[rand() % 62];
    }
    IV[b] = '\0';
    strcpy(beta, IV);
}

int encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key,
            unsigned char *iv, unsigned char *ciphertext, int encAlg)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(encAlg == 0) {            // 0 is AES
        if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
            handleErrors();
    }

    else {
        if(1 != EVP_EncryptInit_ex(ctx, EVP_des_ede3_cbc(), NULL, key, iv))
            handleErrors();
    }
    

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *iv, unsigned char *plaintext, int encAlg)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(encAlg == 0) {               // 0 is AES
        if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
            handleErrors();
    }

    else {
        if(1 != EVP_DecryptInit_ex(ctx, EVP_des_ede3_cbc(), NULL, key, iv))
            handleErrors();
    }
    

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int Base64Encode(const unsigned char* buffer, size_t length, char** b64text) { //Encodes a binary safe base 64 string
    BIO *bio, *b64;
    BUF_MEM *bufferPtr;

    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Ignore newlines - write everything in one line
    BIO_write(bio, buffer, length);
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &bufferPtr);
    BIO_set_close(bio, BIO_NOCLOSE);
    BIO_free_all(bio);

    *b64text=(*bufferPtr).data;

    return (0); //success
}

size_t calcDecodeLength(const char* b64input) { //Calculates the length of a decoded string
    size_t len = strlen(b64input),
        padding = 0;

    if (b64input[len-1] == '=' && b64input[len-2] == '=') //last two chars are =
        padding = 2;
    else if (b64input[len-1] == '=') //last char is =
        padding = 1;

    return (len*3)/4 - padding;
}

int Base64Decode(char* b64message, unsigned char** buffer, size_t* length) { //Decodes a base64 encoded string
    BIO *bio, *b64;

    int decodeLen = calcDecodeLength(b64message);
    *buffer = (unsigned char*)malloc(decodeLen + 1);
    (*buffer)[decodeLen] = '\0';

    bio = BIO_new_mem_buf(b64message, -1);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Do not use newlines to flush buffer
    *length = BIO_read(bio, *buffer, strlen(b64message));
    assert(*length == decodeLen); //length should equal decodeLen, else something went horribly wrong
    BIO_free_all(bio);

    return (0); //success
}

int myencrypt(char *plaintext, unsigned char *key, unsigned char *iv, char ciphertext_base64[], int encAlg){
    unsigned char ciphertext[1024];

    int ciphertext_len;
    ciphertext_len = encrypt(plaintext, strlen ((char *)plaintext), key, iv, ciphertext, encAlg);

    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);
    
    strcpy(ciphertext_base64,ciphertext_base);

    // returns original ciphertext length
    return ciphertext_len;
}

void mydecrypt(char * ciphertext_base64, unsigned char *key, unsigned char *iv, int length, unsigned char decryptedtext[], int encAlg){
    
    unsigned char* base64DecodeOutput;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeOutput, &test);

    int decryptedtext_len;
    decryptedtext_len = decrypt(base64DecodeOutput, length, key, iv,
                                decryptedtext, encAlg);

    decryptedtext[decryptedtext_len] = '\0';
}

void digest_message(const unsigned char *message, size_t message_len, unsigned char **digest, unsigned int *digest_len, int type)
{
	EVP_MD_CTX *mdctx;

	if((mdctx = EVP_MD_CTX_new()) == NULL)
		handleErrors();
    if(type == 0) {
        if(1 != EVP_DigestInit_ex(mdctx, EVP_sha512(), NULL))
            handleErrors();

        if(1 != EVP_DigestUpdate(mdctx, message, message_len))
		    handleErrors();

        if((*digest = (unsigned char *)OPENSSL_malloc(EVP_MD_size(EVP_sha512()))) == NULL)
		    handleErrors();
    }
    else {
        if(1 != EVP_DigestInit_ex(mdctx, EVP_sha3_512(), NULL))
		    handleErrors();
        
        if(1 != EVP_DigestUpdate(mdctx, message, message_len))
		    handleErrors();

        if((*digest = (unsigned char *)OPENSSL_malloc(EVP_MD_size(EVP_sha3_512()))) == NULL)
		    handleErrors();
    }

	if(1 != EVP_DigestFinal_ex(mdctx, *digest, digest_len))
		handleErrors();

	EVP_MD_CTX_free(mdctx);
}

void myhash(char *msg, char base64_hash[], int type) {
    
    unsigned char *digest;
    int digest_len;
    digest_message(msg, strlen(msg), &digest, &digest_len, type);

    char *hash_base;
    Base64Encode(digest, digest_len, &hash_base);

    strcpy(base64_hash, hash_base);

}

void RSAKeypairGen(char* username, int keylen) {
	size_t pri_len;            // Length of private key
    size_t pub_len;            // Length of public key
    char   *pri_key;           // Private key
    char   *pub_key;           // Public key

    printf("Generating RSA (%d bits) keypair for %s...\n", keylen, username);
    fflush(stdout);

    char fpub[1024], fpriv[1024], len[10];
    
    sprintf(len,"%d",keylen);

    strcpy(fpub, username);
    strcat(fpub, "_pub_");
    strcat(fpub, len);
    strcat(fpub, ".txt");

    strcpy(fpriv, username);
    strcat(fpriv, "_priv_");
	strcat(fpriv, len);
	strcat(fpriv, ".txt");

    FILE *fp1 = fopen(fpub, "w");
    FILE *fp2 = fopen(fpriv, "w");

    RSA *keypair = RSA_generate_key(keylen, PUB_EXP, NULL, NULL);

    PEM_write_RSAPublicKey(fp1, keypair);
    PEM_write_RSAPrivateKey(fp2, keypair, NULL, NULL, 0, NULL, NULL);

    fflush(fp1);
    fflush(fp2);

    fclose(fp1);
    fclose(fp2);

    return;
}



int my_pubkey_encrypt(char *msg, char* base64_enc_msg, char *receiver, int keylen) {
	RSA *rsa = NULL;

	char fpub[1024], len[10];
    
    sprintf(len,"%d",keylen);

    strcpy(fpub, receiver);
    strcat(fpub, "_pub_");
    strcat(fpub, len);
    strcat(fpub, ".txt");

    FILE* fp = fopen(fpub, "r");

    rsa = PEM_read_RSAPublicKey(fp, &rsa, NULL, NULL);

    char *ciphertext = malloc(RSA_size(rsa));
    
    int ciphertext_len;
    ciphertext_len = RSA_public_encrypt(strlen(msg)+1, (unsigned char*)msg, (unsigned char*)ciphertext, rsa, RSA_PKCS1_OAEP_PADDING);
    
    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);

    strcpy(base64_enc_msg, ciphertext_base);

    fclose(fp);

    printf("Message Encrypted\n");

    return ciphertext_len;

}

void my_privkey_decrypt(char* ciphertext_base64, char dec_msg[], char* owner, int keylen, int length) {
	RSA *rsa = NULL;

	char fpriv[1024], len[10];
    
    sprintf(len,"%d",keylen);

    strcpy(fpriv, owner);
    strcat(fpriv, "_priv_");
    strcat(fpriv, len);
    strcat(fpriv, ".txt");

    FILE *fp; 

    fp = fopen(fpriv, "r");

    rsa = PEM_read_RSAPrivateKey(fp, &rsa, NULL, NULL);
    fclose(fp);

    unsigned char* base64DecodeOutput;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeOutput, &test);
    
	int decrypted_len;
    decrypted_len = RSA_private_decrypt(length, (unsigned char*)base64DecodeOutput, (unsigned char*)dec_msg, rsa, RSA_PKCS1_OAEP_PADDING);
    
    dec_msg[decrypted_len] = '\0';
	
    printf("Message decrypted \n");
	
	return;
}

int my_privkey_encrypt(char *msg, char* base64_enc_msg, char *sender, int keylen) {
	RSA *rsa = NULL;

	char fpriv[1024], len[10];
    
    sprintf(len,"%d",keylen);

    strcpy(fpriv, sender);
    strcat(fpriv, "_priv_");
    strcat(fpriv, len);
    strcat(fpriv, ".txt");

    FILE* fp = fopen(fpriv, "r");

    rsa = PEM_read_RSAPrivateKey(fp, &rsa, NULL, NULL);
    
    char *ciphertext = malloc(RSA_size(rsa));
    
    int ciphertext_len;
    ciphertext_len = RSA_private_encrypt(strlen(msg)+1, (unsigned char*)msg, (unsigned char*)ciphertext, rsa, RSA_PKCS1_PADDING);

    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);

    strcpy(base64_enc_msg, ciphertext_base);

    fclose(fp);

    printf("Digital signature to message is generated\n");

    return ciphertext_len;

}

void my_pubkey_decrypt(char* ciphertext_base64, char dec_msg[], char* sender, int keylen, int length) {
	RSA *rsa = NULL;

	char fpub[1024], len[10];
    
    sprintf(len,"%d",keylen);

    strcpy(fpub, sender);
    strcat(fpub, "_pub_");
    strcat(fpub, len);
    strcat(fpub, ".txt");

    FILE *fp; 

    fp = fopen(fpub, "r");

    rsa = PEM_read_RSAPublicKey(fp, &rsa, NULL, NULL);
    fclose(fp);

    unsigned char* base64DecodeOutput;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeOutput, &test);

    int decrypted_len;
	decrypted_len = RSA_public_decrypt(length, (unsigned char*)base64DecodeOutput, (unsigned char*)dec_msg, rsa, RSA_PKCS1_PADDING);
	
    dec_msg[decrypted_len] = '\0';

	printf("Decrypted message is generated\nNow, one can verify for signature\n");
	
	return;
}


void only_conf_ENC(char* sender, char* receiver, char* inpfile, char* outfile, int symEncType, int keylen) {
    char KS[64], IV[64];
    char base64_enc_temp2[4098];

    FILE *inp, *out;
    inp = fopen(inpfile, "r");

    char* msg;
    int msg_len;
    if(inp) {
        fseek (inp, 0, SEEK_END);
        msg_len = ftell (inp);
        fseek (inp, 0, SEEK_SET);
        msg = (char*)malloc(msg_len+1);
        if(msg) {
            fread(msg, 1, msg_len, inp);
        }
        fclose(inp);    
    }
    msg[msg_len] = '\0';
    // printf("msg is:\n%s\n", msg);

    if(symEncType == 0) {     // AES 256-bit key
        genRanKey(KS, IV, 32, 16);
    }
    else if (symEncType == 1) {     // DES
        genRanKey(KS, IV, 24, 8);
    }

    int a2 = myencrypt(msg, KS, IV, base64_enc_temp2, symEncType);


    char l2[10];
    sprintf(l2,"%d",a2);

    char temp[4098];
    strcpy(temp, KS);
    strcat(temp, "$");
    strcat(temp, IV);

    char base64_enc_temp[4098];
    int a1 = my_pubkey_encrypt(temp, base64_enc_temp, receiver, keylen);
    
    char l1[10];
    sprintf(l1,"%d",a1);

    char buff[4098];
    strcpy(buff, base64_enc_temp);
    strcat(buff, "|");
    strcat(buff, l1);
    strcat(buff, "\n|");
    strcat(buff, base64_enc_temp2);
    strcat(buff, "|");
    strcat(buff, l2);

    out = fopen(outfile, "w");
    fprintf(out, "%s", buff);

}

void only_conf_DEC(char* sender, char* receiver, char* inpfile, char* outfile, int symEncType, int keylen) {
    FILE *inp, *out;
    inp = fopen(inpfile, "r");

    char* enc_text;
    int enc_text_len;
    if(inp) {
        fseek (inp, 0, SEEK_END);
        enc_text_len = ftell (inp);
        fseek (inp, 0, SEEK_SET);
        enc_text = (char*)malloc(enc_text_len);
        if(enc_text) {
            fread(enc_text, 1, enc_text_len, inp);
        }
        fclose(inp);    
    }

    // printf("enc_text: %s\n", enc_text);

    char *r1[4];
    char * token = strtok(enc_text, "|");
    int i = 0;
    while( token != NULL ) {
        r1[i++] = token;
        token = strtok(NULL, "|");
    }

    int a1 = atoi(r1[1]);
    int a2 = atoi(r1[3]);

    char decrypted_key[4098];
    my_privkey_decrypt(r1[0], decrypted_key, receiver, keylen, a1);

    // printf("decrypted key: %s\n", decrypted_key);

    char *r2[2];
    char * token1 = strtok(decrypted_key, "$");
    i = 0;
    while( token1 != NULL ) {
        r2[i++] = token1;
        token1 = strtok(NULL, "$");
    }

    char decrypted_msg[4098];
    mydecrypt(r1[2], r2[0], r2[1], a2, decrypted_msg, symEncType);
    
    out = fopen(outfile, "w");
    fprintf(out, "%s", decrypted_msg);
    fclose(out);

}


void only_AUIN_ENC(char* sender, char* receiver, char* inpfile, char* outfile, int symEncType, int hashtype, int keylen) {
    FILE *inp, *out;
    inp = fopen(inpfile, "r");

    char* msg;
    int msg_len;
    if(inp) {
        fseek (inp, 0, SEEK_END);
        msg_len = ftell (inp);
        fseek (inp, 0, SEEK_SET);
        msg = (char*)malloc(msg_len+1);
        if(msg) {
            fread(msg, 1, msg_len, inp);
        }
        fclose(inp);    
    }
    msg[msg_len] = '\0';
    // printf("msg: %s\n", msg);

    char base64_hash[4098];
	myhash(msg, base64_hash, hashtype);
    // printf("base64 encoding of hash is:\n%s\n", base64_hash);

    char base64_enc_hash[4098];
    int a1 = my_privkey_encrypt(base64_hash, base64_enc_hash, sender, keylen);

    char l1[10];
    sprintf(l1,"%d",a1);

    char buff[4098];
    strcpy(buff, base64_enc_hash);
    strcat(buff, "|");
    strcat(buff, l1);
    strcat(buff, "\n|");
    strcat(buff, msg);

    out = fopen(outfile, "w");
    fprintf(out, "%s", buff);

}

void only_AUIN_DEC(char* sender, char* receiver, char* inpfile, char* outfile, int symEncType, int hashtype, int keylen) {
    FILE *inp, *out;
    inp = fopen(inpfile, "r");

    char* enc_text;
    int enc_text_len;
    if(inp) {
        fseek (inp, 0, SEEK_END);
        enc_text_len = ftell (inp);
        fseek (inp, 0, SEEK_SET);
        enc_text = (char*)malloc(enc_text_len+1);
        if(enc_text) {
            fread(enc_text, 1, enc_text_len, inp);
        }
        fclose(inp);    
    }
    enc_text[enc_text_len] = '\0';

    char *r1[3];
    char * token = strtok(enc_text, "|");
    int i = 0;
    while( token != NULL ) {
        r1[i++] = token;
        token = strtok(NULL, "|");
    }

    int a1 = atoi(r1[1]);

    char decrypted_hash[4098];
    my_pubkey_decrypt(r1[0], decrypted_hash, sender, keylen, a1);
    // printf("decrypted hash is:\n%s\n", decrypted_hash);

    char base64_hash[4098];
	myhash(r1[2], base64_hash, hashtype);
    // printf("new hash is: \n%s\n", base64_hash);
    
    out = fopen(outfile, "w");
    if(strcmp(base64_hash, decrypted_hash) == 0)  {
        printf("Verification check passed\n");
        fprintf(out, "%s", r1[2]);
    }
    else {
        printf("integrity check FAILED\n");
    }
    fclose(out);

}


void COAI_enc(char* sender, char* receiver, char* inpfile, char* outfile, int symEncType, int hashtype, int keylen) {
    
    FILE *inp, *out;
    inp = fopen(inpfile, "r");

    char* msg;
    int msg_len;
    if(inp) {
        fseek (inp, 0, SEEK_END);
        msg_len = ftell (inp);
        fseek (inp, 0, SEEK_SET);
        msg = (char*)malloc(msg_len+1);
        if(msg) {
            fread(msg, 1, msg_len, inp);
        }
        fclose(inp);    
    }
    msg[msg_len] = '\0';

    char base64_hash[4098];
	myhash(msg, base64_hash, hashtype);
    
    char base64_enc_hash[4098];
    int a1 = my_privkey_encrypt(base64_hash, base64_enc_hash, sender, keylen);

    char l1[10];
    sprintf(l1,"%d",a1);

    char buff[4098];
    strcpy(buff, base64_enc_hash);
    strcat(buff, "|");
    strcat(buff, l1);
    strcat(buff, "\n|");
    strcat(buff, msg);

    char KS[64], IV[64];
    char base64_enc_temp2[4098];

    if(symEncType == 0) {     // AES 256-bit key
        genRanKey(KS, IV, 32, 16);
    }
    else if (symEncType == 1) {     // DES
        genRanKey(KS, IV, 24, 8);
    }

    int a2 = myencrypt(buff, KS, IV, base64_enc_temp2, symEncType);

    char l2[10];
    sprintf(l2,"%d",a2);

    char temp[4098];
    strcpy(temp, KS);
    strcat(temp, "$");
    strcat(temp, IV);

    char base64_enc_temp[4098];
    int a3 = my_pubkey_encrypt(temp, base64_enc_temp, receiver, keylen);
    
    char l3[10];
    sprintf(l3,"%d",a3);

    char buff2[4098];
    strcpy(buff2, base64_enc_temp);
    strcat(buff2, "|");
    strcat(buff2, l3);
    strcat(buff2, "\n|");
    strcat(buff2, base64_enc_temp2);
    strcat(buff2, "|");
    strcat(buff2, l2);

    out = fopen(outfile, "w");
    fprintf(out, "%s", buff2);
    fclose(out);

}

void COAI_dec(char* sender, char* receiver, char* inpfile, char* outfile, int symEncType, int hashtype, int keylen) {
    
    only_conf_DEC(sender, receiver, inpfile, "temp_inpfile.txt", symEncType, keylen);
    only_AUIN_DEC(sender, receiver, "temp_inpfile.txt", outfile, symEncType, hashtype, keylen);

}


int main(int argc, char* argv[]) {

    if(strcmp(argv[1], "CreateKeys") == 0) {
        char user[100];
        int keysize = atoi(argv[3]);
        FILE *fp = fopen(argv[2], "r");
        while(fscanf(fp, "%s", user) != EOF) {
            RSAKeypairGen(user, keysize);
        }
    }

    else if(strcmp(argv[1], "CreateMail") == 0) {
        if(strcmp(argv[2], "CONF") == 0) {
            int type = 0, keylen = atoi(argv[9]);
            if(strcmp(argv[8], "des-ede3-cbc") == 0) {
                type = 1;
            }
            only_conf_ENC(argv[3], argv[4], argv[5], argv[6], type, keylen);
        }
        else if(strcmp(argv[2], "AUIN") == 0) {
            int type = 0, hashtype = 0, keylen = atoi(argv[9]);
            if(strcmp(argv[8], "des-ede3-cbc") == 0) {
                type = 1;
            }
            if(strcmp(argv[7], "sha3-512") == 0) {
                hashtype = 1;
            }
            only_AUIN_ENC(argv[3], argv[4], argv[5], argv[6], type, hashtype, keylen);
        }
        else if(strcmp(argv[2], "COAI") == 0) {
            int type = 0, hashtype = 0, keylen = atoi(argv[9]);
            if(strcmp(argv[8], "des-ede3-cbc") == 0) {
                type = 1;
            }
            if(strcmp(argv[7], "sha3-512") == 0) {
                hashtype = 1;
            }
            COAI_enc(argv[3], argv[4], argv[5], argv[6], type, hashtype, keylen);
        }
        else {
            printf("Incorrect type\n");
        }
    }

    else if(strcmp(argv[1], "ReadMail") == 0) {
        if(strcmp(argv[2], "CONF") == 0) {
            int type = 0, keylen = atoi(argv[9]);
            if(strcmp(argv[8], "des-ede3-cbc") == 0) {
                type = 1;
            }
            only_conf_DEC(argv[3], argv[4], argv[5], argv[6], type, keylen);
        }
        else if(strcmp(argv[2], "AUIN") == 0) {
            int type = 0, hashtype = 0, keylen = atoi(argv[9]);
            if(strcmp(argv[8], "des-ede3-cbc") == 0) {
                type = 1;
            }
            if(strcmp(argv[7], "sha3-512") == 0) {
                hashtype = 1;
            }
            only_AUIN_DEC(argv[3], argv[4], argv[5], argv[6], type, hashtype, keylen);
        }
        else if(strcmp(argv[2], "COAI") == 0) {
            int type = 0, hashtype = 0, keylen = atoi(argv[9]);
            if(strcmp(argv[8], "des-ede3-cbc") == 0) {
                type = 1;
            }
            if(strcmp(argv[7], "sha3-512") == 0) {
                hashtype = 1;
            }
            COAI_dec(argv[3], argv[4], argv[5], argv[6], type, hashtype, keylen);
        }
        else {
            printf("Incorrect type\n");
        }
    }
    else {
        printf("Wrong Input\n");
    }
    
    // char *user1 = "alice";
	// char *user2 = "bob";
	
	// RSAKeypairGen(user1, 1024);
	// RSAKeypairGen(user2, 1024);
    
    // char* msg = "Hello World\nHai";
    
    // char base64_enc_msg[4098], dec_msg[4098];

    // int a = my_pubkey_encrypt(msg, base64_enc_msg, user2, 1024);
    // my_privkey_decrypt(base64_enc_msg, dec_msg, user2, 1024, a);

    // printf("%s\n", dec_msg);

    // int a = my_privkey_encrypt(msg, base64_enc_msg, user2, 1024);
    // my_pubkey_decrypt(base64_enc_msg, dec_msg, user2, 1024, a);

    // printf("%s\n", dec_msg);

    // char KS[4098], IV[4098], enc_msg[4098], dec_msg[4098];
    // genRanKey(KS, IV, 32, 16); 

    // int a = myencrypt(msg, KS, IV, enc_msg, 0);
    // mydecrypt(enc_msg, KS, IV, a, dec_msg, 0);

    // printf("%s\n", dec_msg);
    return 0;
}