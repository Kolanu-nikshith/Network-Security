#include<bits/stdc++.h>
#include<fstream>
using namespace std;
// using namespace std::chrono;

class Rule {
    public:
        int num;
        string src_ip, dest_ip;
        int src_port_l, src_port_u;
        int dest_port_l, dest_port_u;
        string protocol;
        string data;
        bool isValid;
};

class Packet {
    public:
        int num;
        string src_ip;
        string dest_ip;
        int src_port;
        int dest_port;
        string protocol;
        string data;
};

vector<Packet*> packets;
vector<Rule*> rules;

bool isValidPort(int a, int b) {
    if(a < 1 || a > 65535 || b < 1 || b > 65535) {
        return false;
    }
    return true;
}

bool isValidPort(int a, int b, int c, int d) {
    if(a > b || c > d) {
        return false;
    }
    if(a < 1 || a > 65535 || b < 1 || b > 65535) {
        if(a != 0 || b != 0) {
            return false;
        }
    }
    if(c < 1 || c > 65535 || d < 1 || d > 65535) {
        if(c != 0 || d != 0) {
            return false;
        }
    }
    return true;
}

string decToBin(string a) {
    int n = stoi(a);
    int bin[8] = {0};
    int i = 0;
    while(n>0) {
        bin[i] = n%2;
        n /= 2;
        i++;
    }
    string res = "";
    for(int i = 7; i >= 0; i--) {
        char c = bin[i]+'0';
        res = res + c;
    }
    return res;
}

bool isPrefixMatch(string a, string b) {
    
    string ruleBinIp = "", pcktBinIp = "";

    stringstream ss(a);
    string ip, prefix;

    getline(ss, ip, '/');
    getline(ss, prefix, '/');
    int pre = stoi(prefix);

    stringstream ss2(ip);
    string s;
    while(getline(ss2, s, '.')) {
        ruleBinIp = ruleBinIp + decToBin(s);
    }

    stringstream ss3(b);
    while(getline(ss3, s, '.')) {
        pcktBinIp = pcktBinIp + decToBin(s);
    }

    for(int i = 0; i < pre; i++) {
        if(pcktBinIp[i] != ruleBinIp[i]) {
            return false;
        }
    }
    return true;

}

bool isSatisfied(Packet pckt, Rule rule) {
    // protocol mismatch
    if(pckt.protocol != rule.protocol) {  
        return false;
    }
    // src port mismatch
    if(rule.src_port_l != 0 || rule.src_port_u != 0) { 
        if(pckt.src_port > rule.src_port_u || pckt.src_port < rule.src_port_l)
            return false;
    }
    // dest port mismatch
    if(rule.dest_port_l != 0 || rule.dest_port_u != 0) {
        if(pckt.dest_port > rule.dest_port_u || pckt.dest_port < rule.dest_port_l)
            return false;
    }
    // data mismatch
    if(rule.data != "*") {
        size_t found = pckt.data.find(rule.data);
        if(found == string::npos) {
            return false;
        }
    }
    // src ip addr mismatch
    if(rule.src_ip != "0.0.0.0/0") {
        if(!isPrefixMatch(rule.src_ip, pckt.src_ip)) {
            return false;
        }
    }
    // dest ip addr mismatch
    if(rule.dest_ip != "0.0.0.0/0") {
        if(!isPrefixMatch(rule.dest_ip, pckt.dest_ip)) {
            return false;
        }
    }
    return true;
}

void readRules(char* ruleFile) {
    ifstream fp;
    fp.open(ruleFile);

    string line;
    Rule *rule;
    int read_count = 0;

    while(getline(fp, line)) {

        stringstream s(line);
        string word;
        vector<string> wordsInLine;
        while(s >> word) {
            wordsInLine.push_back(word);
        }
        if(wordsInLine[0] == "BEGIN") {
            rule = new Rule();
        }
        else if(wordsInLine[0] == "NUM:") {
            rule -> num = stoi(wordsInLine[1]);
        }
        else if(wordsInLine[0] == "SRC" && wordsInLine[1] == "IP") {
            rule -> src_ip = wordsInLine[3];
        }
        else if(wordsInLine[0] == "DEST" && wordsInLine[1] == "IP") {
            rule -> dest_ip = wordsInLine[3];
        }
        else if(wordsInLine[0] == "SRC" && wordsInLine[1] == "PORT:") {
            stringstream ss(wordsInLine[2]);
            string prtNum_l, prtNum_u;
            getline(ss, prtNum_l, '-');
            getline(ss, prtNum_u, '-');

            rule -> src_port_l = stoi(prtNum_l);
            rule -> src_port_u = stoi(prtNum_u);
        }
        else if(wordsInLine[0] == "DEST" && wordsInLine[1] == "PORT:") {
            stringstream ss(wordsInLine[2]);
            string prtNum_l, prtNum_u;
            getline(ss, prtNum_l, '-');
            getline(ss, prtNum_u, '-');

            rule -> dest_port_l = stoi(prtNum_l);
            rule -> dest_port_u = stoi(prtNum_u);
        }
        else if(wordsInLine[0] == "PROTOCOL:") {
            rule -> protocol = wordsInLine[1];
        }
        else if(wordsInLine[0] == "DATA:") {
            string str = "";
            int i = 1;
            while(i < wordsInLine.size()) {
                str = str + wordsInLine[i];
                str = str + " ";
                i++;
            }
            str.pop_back(); // this will give a seg fault is data is empty
            rule -> data = str;
        }
        else if (wordsInLine[0] == "END") {
            rules.push_back(rule);
        }
    }
    cout << "A total of " << rules.size() << " rules were read; ";
    return;
}

void processRules() {
    int count = 0;
    for(int i = 0; i < rules.size(); i++) {
        if(isValidPort(rules[i]->src_port_l, rules[i]->src_port_u, rules[i]->dest_port_l, rules[i]->dest_port_u)) {
            rules[i] -> isValid = true;
            count++;
        }
        else {
            rules[i] -> isValid = false;
        }
    }
    cout << count << " valid rules are stored" << endl;
}

void readPackets(char* pcktFile) {

    ifstream fp;
    fp.open(pcktFile);

    string line;
    Packet *pckt;
    
    while(getline(fp, line)) {
        
        stringstream s(line);
        string word;
        vector<string> wordsInLine;
        while(s >> word) {
            wordsInLine.push_back(word);
        }
        if(wordsInLine[0] == "BEGIN") {
            pckt = new Packet();
        }
        else if(wordsInLine[0] == "NUM:") {
            pckt -> num = stoi(wordsInLine[1]);
        }
        else if(wordsInLine[0] == "SRC" && wordsInLine[1] == "IP") {
            pckt -> src_ip = wordsInLine[3];
        }
        else if(wordsInLine[0] == "DEST" && wordsInLine[1] == "IP") {
            pckt -> dest_ip = wordsInLine[3];
        }
        else if(wordsInLine[0] == "SRC" && wordsInLine[1] == "PORT:") {
            pckt -> src_port = stoi(wordsInLine[2]);
        }
        else if(wordsInLine[0] == "DEST" && wordsInLine[1] == "PORT:") {
            pckt -> dest_port = stoi(wordsInLine[2]);
        }
        else if(wordsInLine[0] == "PROTOCOL:") {
            pckt -> protocol = wordsInLine[1];
        }
        else if(wordsInLine[0] == "DATA:") {
            string str = "";
            int i = 1;
            while(i < wordsInLine.size()) {
                str = str + wordsInLine[i];
                str = str + " ";
                i++;
            }
            str.pop_back(); // this will give a seg fault is data is empty
            pckt -> data = str;
        }
        else if (wordsInLine[0] == "END") {
            packets.push_back(pckt);
        }
    }
    return;
}

void processPackets() {
    int total = 0;
    for(int i = 0; i < packets.size(); i++) {
        cout << "Packet number " << packets[i]->num; 
        auto start = chrono::high_resolution_clock::now();
        if(!isValidPort(packets[i]->src_port, packets[i]->dest_port)) {
            cout << " is invalid" << endl;;
        }
        else {
            vector<int> satRules;
            for(int j = 0; j < rules.size(); j++) {
                if(rules[j]->isValid == false) {
                    continue;
                }
                if( isSatisfied( *(packets[i]), *(rules[j]) ) ) {
                    satRules.push_back(rules[j]->num);
                }
            }
            cout << " matches " << satRules.size() << " rule(s):";
            for(int j = 0; j < satRules.size(); j++) {
                cout << " " << satRules[j];
            }
            cout << endl;
        }
        auto stop = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(stop-start);
        // cout << "time=" << duration.count() << " microseconds" << endl;
        total += duration.count();
    }
    int n = packets.size();
    cout << "A total of " << n << " packet(s) were read from the file and processed. Bye." << endl;
    float avg_time = total/(1.0*n);
    cout << "Average time taken per packet: " << avg_time << " microseconds." << endl;
    return;
}

int main(int argc, char* argv[]) {
    char pcktFile[100], ruleFile[100];
    
    strcpy(ruleFile, argv[1]);
    strcpy(pcktFile, argv[2]);

    readRules(ruleFile);
    processRules();
    
    readPackets(pcktFile);
    processPackets();
    
    return 0;
}