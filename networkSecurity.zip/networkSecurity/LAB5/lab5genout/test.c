#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <sys/time.h>

for (rulenum = 1; rulenum <= numrules; rulenum++)
    {
      pkts_rule = 2 + random() % 5;
      fprintf(stdout,"RULE: %d\n", rulenum);
      print_src_addr_rule(stdout, RULE_ARR[rulenum].sa1,RULE_ARR[rulenum].sa2,RULE_ARR[rulenum].sa3,RULE_ARR[rulenum].sa4,RULE_ARR[rulenum].slen);
 
      for (k = 0; k < pkts_rule; k++)
	  {
	  	pktnum++;
	  	fprintf(stdout,"\t\t\tPKT: %d\n", pktnum);
	  	fprintf(fppkt,"BEGIN\n");
	  	fprintf(fppkt,"NUM: %d\n", pktnum);
      
	  	if (RULE_ARR[rulenum].slen == 0)
		{
	      a1 = 1 + random() % 254;
	      a2 = 1 + random() % 254;
	      a3 = 1 + random() % 254;
	      a4 = 1 + random() % 254;
	    }
	  	if (RULE_ARR[rulenum].slen == 8)
	    {
	      a1 = RULE_ARR[rulenum].sa1;
	      a2 = 1 + random() % 254;
	      a3 = 1 + random() % 254;
	      a4 = 1 + random() % 254;
	    } /* address of length 8 */
	  	if (RULE_ARR[rulenum].slen == 12)
	    {
	      a1 = RULE_ARR[rulenum].sa1;
	      a2 = RULE_ARR[rulenum].sa2 + random() % 16;
	      a3 = 1 + random() % 254;
	      a4 = 1 + random() % 254;
	    }/* address of length 12 */
	  	if (RULE_ARR[rulenum].slen == 20)
	    {
	      a1 = RULE_ARR[rulenum].sa1;
	      a2 = RULE_ARR[rulenum].sa2;
	      a3 = RULE_ARR[rulenum].sa3 + random() % 16;
	      a4 = 1 + random() % 254;
	    }/* address of length 20 */

	  	print_src_addr_pkt(fppkt, a1, a2, a3, a4);
	  	//	  fprintf(stdout,"\t\t\t");
	  	//	  print_src_addr_pkt(stdout, a1, a2, a3, a4);

	  	if (RULE_ARR[rulenum].dlen == 0)
	    {
	      a1 = 1 + random() % 254;
	      a2 = 1 + random() % 254;
	      a3 = 1 + random() % 254;
	      a4 = 1 + random() % 254;
	    }
	  	if (RULE_ARR[rulenum].dlen == 8)
	    {
	      a1 = RULE_ARR[rulenum].da1;
	      a2 = 1 + random() % 254;
	      a3 = 1 + random() % 254;
	      a4 = 1 + random() % 254;
	    } /* address of length 8 */
	  	if (RULE_ARR[rulenum].dlen == 12)
	    {
	      a1 = RULE_ARR[rulenum].da1;
	      a2 = RULE_ARR[rulenum].da2 + random() % 16;
	      a3 = 1 + random() % 254;
	      a4 = 1 + random() % 254;
	    }/* address of length 12 */
	  	if (RULE_ARR[rulenum].dlen == 20)
	    {
	      a1 = RULE_ARR[rulenum].da1;
	      a2 = RULE_ARR[rulenum].da2;
	      a3 = RULE_ARR[rulenum].da3 + random() % 16;
	      a4 = 1 + random() % 254;
	    }/* address of length 20 */

	  	print_dest_addr_pkt(fppkt, a1, a2, a3, a4);
	  	//	  fprintf(stdout,"\t\t\t");
	  	//	  print_src_addr_pkt(stdout, a1, a2, a3, a4);

	  	if (RULE_ARR[rulenum].sp1 == 0)
	      p1 = 1 + random() % 65535;
	  	else
	    {
	      p1 = RULE_ARR[rulenum].sp1 +
			random()%(RULE_ARR[rulenum].sp2 - RULE_ARR[rulenum].sp1 + 1);
	    }

	  	fprintf(fppkt,"SRC PORT: %d\n", p1);

	  	if (RULE_ARR[rulenum].dp1 == 0)
	      p1 = 1 + random() % 65535;
	  	else
	    {
	      temp = random() % 5;
	      if (temp > 0)
			p1 = RULE_ARR[rulenum].dp1 +
		    random()%(RULE_ARR[rulenum].dp2 - RULE_ARR[rulenum].dp1 + 1);
	      else		/* Deliberately Out of range */
			p1 = 65536 + (random() % 65536);
	    }

	  	fprintf(fppkt,"DEST PORT: %d\n", p1);

	  	/* PROTOCOL */      
	  	temp = random() % 4;
	  	if (temp > 0)
	      fprintf(fppkt,"PROTOCOL: %s\n", RULE_ARR[rulenum].proto);
	  	else
	      fprintf(fppkt,"PROTOCOL: %s\n", protocols[random()%3]);

	  	int i, m;
	  	for (i = 0; i < 100; i++)
	    	PktData[i] = GenChar();
	  	PktData[100] = '\0';

	  	if (drand48() > 0.2)	/* Include string in packet from rule */
	    {			/* 80% of the time */
	      m = random() % 90; /* Random starting point to add string  */
	      /* strncpy 10 bytes from rule to replace this with prob. 0.8 */
	      for (int j = 0; j < 10; j++)
			PktData[m+j] = RULE_ARR[rulenum].Data[j];
	      fprintf(stdout,"%s; %s\n", PktData, RULE_ARR[rulenum].Data);
	    }

	  	fprintf(fppkt,"DATA: %s\n", PktData);

	  	fprintf(fppkt,"END\n");
	}
}