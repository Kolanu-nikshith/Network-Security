#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include <netdb.h> 
#include<math.h>
#include <netinet/in.h> 
#include <sys/socket.h> 
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <assert.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/des.h>
#include <openssl/sha.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define KEY_LEN     1024
#define PUB_EXP     3
#define MAX         1024

void handleErrors(void)
{
    ERR_print_errors_fp(stderr);
    // fprintf(stderr, "ERROR!!Wrong credentials given.Aborting...\n");
    abort();
}

int CBCencrypt2(unsigned char *plaintext, int plaintext_len, unsigned char *key,
            unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    // 0 is AES
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();
    

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int CBCdecrypt2(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
                   // 0 is AES
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}


int Base64Encode(const unsigned char* buffer, size_t length, char** b64text) { //Encodes a binary safe base 64 string
    BIO *bio, *b64;
    BUF_MEM *bufferPtr;

    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Ignore newlines - write everything in one line
    BIO_write(bio, buffer, length);
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &bufferPtr);
    BIO_set_close(bio, BIO_NOCLOSE);
    BIO_free_all(bio);

    *b64text=(*bufferPtr).data;

    return (0); //success
}

size_t calcDecodeLength(const char* b64input) { //Calculates the length of a decoded string
    size_t len = strlen(b64input),
        padding = 0;

    if (b64input[len-1] == '=' && b64input[len-2] == '=') //last two chars are =
        padding = 2;
    else if (b64input[len-1] == '=') //last char is =
        padding = 1;

    return (len*3)/4 - padding;
}

int Base64Decode(char* b64message, unsigned char** buffer, size_t* length) { //Decodes a base64 encoded string
    BIO *bio, *b64;

    int decodeLen = calcDecodeLength(b64message);
    *buffer = (unsigned char*)malloc(decodeLen + 1);
    (*buffer)[decodeLen] = '\0';

    bio = BIO_new_mem_buf(b64message, -1);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Do not use newlines to flush buffer
    *length = BIO_read(bio, *buffer, strlen(b64message));
    assert(*length == decodeLen); //length should equal decodeLen, else something went horribly wrong
    BIO_free_all(bio);

    return (0); //success
}

int CCMencrypt(unsigned char *plaintext, int plaintext_len,
                // unsigned char *aad, int aad_len,
                unsigned char *key,
                unsigned char *iv,
                unsigned char *ciphertext,
                unsigned char *tag)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;


    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /* Initialise the encryption operation. */
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_ccm(), NULL, NULL, NULL))
        handleErrors();
    

    /*
     * Setting IV len to 7. Not strictly necessary as this is the default
     * but shown here for the purposes of this example.
     */
    // if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_IVLEN, 7, NULL))
    //     handleErrors();

    /* Set tag length */
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_TAG, 14, NULL);

    /* Initialise key and IV */
    if(1 != EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv))
        handleErrors();

    /* Provide the total plaintext length */
    if(1 != EVP_EncryptUpdate(ctx, NULL, &len, NULL, plaintext_len))
        handleErrors();

    /* Provide any AAD data. This can be called zero or one times as required */
    // if(1 != EVP_EncryptUpdate(ctx, NULL, &len, aad, aad_len))
    //     handleErrors();

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can only be called once for this.
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Normally ciphertext bytes may be written at
     * this stage, but this does not occur in CCM mode.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Get the tag */
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_GET_TAG, 14, tag))
        handleErrors();

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int CCMdecrypt(unsigned char *ciphertext, int ciphertext_len,
                // unsigned char *aad, int aad_len,
                unsigned char *tag,
                unsigned char *key,
                unsigned char *iv,
                unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int plaintext_len;
    int ret;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /* Initialise the decryption operation. */
    
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_ccm(), NULL, NULL, NULL))
        handleErrors();
    
    /* Setting IV len to 7. Not strictly necessary as this is the default
     * but shown here for the purposes of this example */
    // if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_IVLEN, 7, NULL))
    //     handleErrors();

    /* Set expected tag value. */
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_TAG, 14, tag))
        handleErrors();

    /* Initialise key and IV */
    if(1 != EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv))
        handleErrors();


    /* Provide the total ciphertext length */
    if(1 != EVP_DecryptUpdate(ctx, NULL, &len, NULL, ciphertext_len))
        handleErrors();

    /* Provide any AAD data. This can be called zero or more times as required */
    // if(1 != EVP_DecryptUpdate(ctx, NULL, &len, aad, aad_len))
    //     handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary
     */
    ret = EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);

    plaintext_len = len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    if(ret > 0) {
        /* Success */
        return plaintext_len;
    } else {
        /* Verify failed */
        return -1;
    }
}

int myencrypt2(char *plaintext, unsigned char *key, unsigned char *iv, char ciphertext_base64[]){
    unsigned char ciphertext[1024];

    int ciphertext_len;
    ciphertext_len = CBCencrypt2(plaintext, strlen((char *)plaintext), key, iv, ciphertext);
    
    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);

    // char *tag_base;
    // Base64Encode(tag, 14, &tag_base);

    strcpy(ciphertext_base64,ciphertext_base);
    // strcpy(tag_base64, tag_base);
    // returns original ciphertext length
    return ciphertext_len;
}

void mydecrypt2(char *ciphertext_base64, unsigned char *key, unsigned char *iv, int length, unsigned char decryptedtext[]){
    
    unsigned char* base64DecodeCipher;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeCipher, &test);

    // unsigned char* base64DecodeTag;
    // Base64Decode(tag_base64, &base64DecodeTag, &test);

    int decryptedtext_len;
    // printf("length is %d\n", length);
    // decryptedtext_len = CCMdecrypt(base64DecodeCipher, length, base64DecodeTag, key, iv,
    //                             decryptedtext);
    decryptedtext_len = CBCdecrypt2(base64DecodeCipher, length, key, iv, decryptedtext);
    // printf("CCMdecrypt successful, len = %d\n", decryptedtext_len);

    decryptedtext[decryptedtext_len] = '\0';
    return;
}


int server_pubkey_encrypt(char* msg, char base64_enc_msg[]) {
    
    RSA *rsa = NULL;

    char filename[MAX];
    sprintf(filename, "clientdir/server_pub.txt");
    
    FILE* fp = fopen(filename, "r");
    if(fp == NULL) {
        printf("ERROR! opening the file\n");
    }
    
    rsa = PEM_read_RSAPublicKey(fp, &rsa, NULL, NULL);

    char *ciphertext = malloc(RSA_size(rsa));
    
    int ciphertext_len;
    ciphertext_len = RSA_public_encrypt(strlen(msg)+1, (unsigned char*)msg, (unsigned char*)ciphertext, rsa, RSA_PKCS1_OAEP_PADDING);
    
    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);
    
    strcpy(base64_enc_msg, ciphertext_base);

    fclose(fp);

    return ciphertext_len;

}

void server_privkey_decrypt(char* ciphertext_base64, char dec_msg[], int length) {
    
    RSA *rsa = NULL;

	char privFile[1024];
    sprintf(privFile, "serverkeys/serverpriv.txt");

    FILE* fp = fopen(privFile, "r");

    rsa = PEM_read_RSAPrivateKey(fp, &rsa, NULL, NULL);
    fclose(fp);

    unsigned char* base64DecodeOutput;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeOutput, &test);
    
	int decrypted_len;
    decrypted_len = RSA_private_decrypt(length, (unsigned char*)base64DecodeOutput, (unsigned char*)dec_msg, rsa, RSA_PKCS1_OAEP_PADDING);
    
    dec_msg[decrypted_len] = '\0';
	
	return;
}

int initiate_connection(int port_b, char *ipaddr_b) {
    int clientSocket;
    char buffer[4098];
    struct sockaddr_in serverAddr;
    socklen_t addr_size;

    clientSocket = socket(AF_INET, SOCK_STREAM, 0);

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port_b);
    serverAddr.sin_addr.s_addr = inet_addr(ipaddr_b);
    memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);

    addr_size = sizeof serverAddr;
    connect(clientSocket, (struct sockaddr *) &serverAddr, addr_size);
    printf("connected to server\n");

    read(clientSocket, buffer, 4098);
    // printf("buffer is %s\n", buffer);
    
    struct stat st = {0};

    if(stat("clientdir", &st) == -1) {
        mkdir("clientdir", 0700);
    }

    char filename[1024];
    sprintf(filename, "clientdir/server_pub.txt");

    FILE* fp = fopen(filename, "w");
    fprintf(fp, "%s", buffer);
    fclose(fp);

    return clientSocket;
}

void sendSessionKey(char *username, char *password, int clientSocket) {

    char buffer[4098];

    char session_key[33];
    srand(time(0));

    char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for(int j = 0; j < 32; j++) {
        session_key[j] = charset[rand() % 62];
    }
    session_key[32] = '\0';
    
    char temp[1024];
    strcpy(temp, username);
    strcat(temp, "|");
    strcat(temp, password);
    strcat(temp, "|");
    strcat(temp, session_key);

    
    char base64_enc_msg[4098];
    int a = server_pubkey_encrypt(temp, base64_enc_msg);
    
    char len[10];
    sprintf(len, "%d", a);

    strcpy(buffer, base64_enc_msg);
    strcat(buffer, "|");
    strcat(buffer, len);
    
    printf("Sending credentials to the server...\n");
    // printf("buffer is :%s\n", buffer);
    write(clientSocket, buffer, 4098);
    
    read(clientSocket, buffer, 4098);

    if(strcmp(buffer, "OK") == 0) {
        printf("Authentication successful. Access granted\n");
    }
    else if(strcmp(buffer, "NOK") == 0) {
        printf("Access Denied. Check credentials entered\n");
        return;
    }

    char command[1024], m[1024];
    int flag = 0;
    
    while(1) {
        
        printf("cmd> ");
        scanf("%s", command);
        if(strcmp(command, "listfiles") == 0) {
            strcpy(m, "LS|");
        }
        else if (strcmp(command, "cwd") == 0) {
            strcpy(m, "PWD|");
        }
        else if (strcmp(command, "chgdir") == 0) {
            char path[1024];
            scanf("%s", path);
            strcpy(m, "CD|");
            strcat(m, path);
        }
        else if (strcmp(command, "cp") == 0) {
            char filename[1024], src[1024], dest[1024];
            scanf("%s%s%s", filename, src, dest);
            strcpy(m, "CP|");
            strcat(m, filename);
            strcat(m, "|");
            strcat(m, src);
            strcat(m, "|");
            strcat(m, dest);
        }
        else if (strcmp(command, "mv") == 0) {
            char filename[1024], src[1024], dest[1024];
            scanf("%s%s%s", filename, src, dest);
            strcpy(m, "MV|");
            strcat(m, filename);
            strcat(m, "|");
            strcat(m, src);
            strcat(m, "|");
            strcat(m, dest);
        }
        else if(strcmp(command, "logout") == 0) {
            strcpy(m, "EXIT|");
            printf("\tExiting....\n");
            flag = 1;
        }
        else {
            printf("\tUnidentified command\n");
            continue;
        }
        // printf("m is :%s\n", m);
        char cipher_base64[4098], dec_text[4098];
        
        int cipher_len = myencrypt2(m, session_key, "1234567890123456", cipher_base64);
        mydecrypt2(cipher_base64, session_key, "1234567890123456", cipher_len, dec_text);
        // printf("dec_text is :%s\n", dec_text);
        
        char len2[10];
        sprintf(len2, "%d", cipher_len);
        
        // memset(buffer, '\0', 4098);
        strcpy(buffer, cipher_base64);
        strcat(buffer, "|");
        // strcat(buffer, tag_base64);
        // strcat(buffer, "|");
        strcat(buffer, len2);
        // strcpy(buffer, m);
        // printf("buffer is :%s\n", buffer);
        write(clientSocket, buffer, 4098);
        // printf("buffer sent to server\n");
        if(flag == 1) {
            break;
        } 
        memset(buffer, '\0', 4098);
        read(clientSocket, buffer, 4098);
        // printf("new buffer is :%s\n", buffer);
        char *r22[2];  
        char * token2 = strtok(buffer, "|");
        int i = 0;
        while( token2 != NULL ) {
            r22[i++] = token2;
            token2 = strtok(NULL, "|");
        }
        char dec_buff[4098];
        mydecrypt2(r22[0], session_key, "1234567890123456", atoi(r22[1]), dec_buff);
        // printf("buffer is :%s\n", buffer);
        // strcpy(dec_buff, buffer);
        char *r11[MAX];  
        char * token = strtok(dec_buff, "|");
        i = 0;
        while( token != NULL ) {
            r11[i++] = token;
            token = strtok(NULL, "|");
        }
        // printf("r11[0] is :%s\n", r11[0]);
        if(strcmp(r11[0], "ERROR") == 0) {
            printf("\tERROR!!No such file or directory\n");
        }
        else if(strcmp(r11[0], "Done") == 0) {
            printf("\tCommand successfully executed\n");
        }
        else  {
            int j = 0;
            while(j < i) {
                printf("\t%s\n",r11[j]);
                j++;
            }
        }
    }
    return;
}
 

int main(int argc, char* argv[]) {

    char username[9], password[17], server_ipaddr[MAX];
    int server_port;
    
    strcpy(username, argv[3]);
    username[8] = '\0';
    strcpy(password, argv[4]);
    password[16] = '\0';
    server_port = atoi(argv[2]);
    strcpy(server_ipaddr, argv[1]);


    int socket_id = initiate_connection(server_port, server_ipaddr);
    sendSessionKey(username, password, socket_id);
    
    return 0;
}