#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<math.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/bio.h>
#include <openssl/buffer.h>
#include <assert.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <openssl/des.h>
#include <openssl/sha.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <netdb.h>
#include <netinet/in.h> 
#include <sys/socket.h>

#define KEY_LEN     1024
#define PUB_EXP     3
#define MAX         4098

char passwords[MAX][17];

void handleErrors(void)
{
    // ERR_print_errors_fp(stderr);
    fprintf(stderr, "ERROR!!Wrong credentials given.Aborting...\n");
    abort();
}

int CBCencrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key,
            unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    // 0 is AES
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv))
        handleErrors();
    

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int CBCdecrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
                   // 0 is AES
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_128_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int CBCencrypt2(unsigned char *plaintext, int plaintext_len, unsigned char *key,
            unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    // 0 is AES
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();
    

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int CBCdecrypt2(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
                   // 0 is AES
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int CCMencrypt(unsigned char *plaintext, int plaintext_len,
                // unsigned char *aad, int aad_len,
                unsigned char *key,
                unsigned char *iv,
                unsigned char *ciphertext,
                unsigned char *tag)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;


    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /* Initialise the encryption operation. */
    if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_ccm(), NULL, NULL, NULL))
        handleErrors();
    

    /*
     * Setting IV len to 7. Not strictly necessary as this is the default
     * but shown here for the purposes of this example.
     */
    // if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_IVLEN, 7, NULL))
    //     handleErrors();

    /* Set tag length */
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_TAG, 14, NULL);

    /* Initialise key and IV */
    if(1 != EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv))
        handleErrors();

    /* Provide the total plaintext length */
    if(1 != EVP_EncryptUpdate(ctx, NULL, &len, NULL, plaintext_len))
        handleErrors();

    /* Provide any AAD data. This can be called zero or one times as required */
    // if(1 != EVP_EncryptUpdate(ctx, NULL, &len, aad, aad_len))
    //     handleErrors();

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can only be called once for this.
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Normally ciphertext bytes may be written at
     * this stage, but this does not occur in CCM mode.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Get the tag */
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_GET_TAG, 14, tag))
        handleErrors();

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int CCMdecrypt(unsigned char *ciphertext, int ciphertext_len,
                // unsigned char *aad, int aad_len,
                unsigned char *tag,
                unsigned char *key,
                unsigned char *iv,
                unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int plaintext_len;
    int ret;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /* Initialise the decryption operation. */
    
    if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_ccm(), NULL, NULL, NULL))
        handleErrors();
    
    /* Setting IV len to 7. Not strictly necessary as this is the default
     * but shown here for the purposes of this example */
    // if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_IVLEN, 7, NULL))
    //     handleErrors();

    /* Set expected tag value. */
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_TAG, 14, tag))
        handleErrors();

    /* Initialise key and IV */
    if(1 != EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv))
        handleErrors();


    /* Provide the total ciphertext length */
    if(1 != EVP_DecryptUpdate(ctx, NULL, &len, NULL, ciphertext_len))
        handleErrors();

    /* Provide any AAD data. This can be called zero or more times as required */
    // if(1 != EVP_DecryptUpdate(ctx, NULL, &len, aad, aad_len))
    //     handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary
     */
    ret = EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);

    plaintext_len = len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    if(ret > 0) {
        /* Success */
        return plaintext_len;
    } else {
        /* Verify failed */
        return -1;
    }
}

int Base64Encode(const unsigned char* buffer, size_t length, char** b64text) { //Encodes a binary safe base 64 string
    BIO *bio, *b64;
    BUF_MEM *bufferPtr;

    b64 = BIO_new(BIO_f_base64());
    bio = BIO_new(BIO_s_mem());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Ignore newlines - write everything in one line
    BIO_write(bio, buffer, length);
    BIO_flush(bio);
    BIO_get_mem_ptr(bio, &bufferPtr);
    BIO_set_close(bio, BIO_NOCLOSE);
    BIO_free_all(bio);

    *b64text=(*bufferPtr).data;

    return (0); //success
}

size_t calcDecodeLength(const char* b64input) { //Calculates the length of a decoded string
    size_t len = strlen(b64input),
        padding = 0;

    if (b64input[len-1] == '=' && b64input[len-2] == '=') //last two chars are =
        padding = 2;
    else if (b64input[len-1] == '=') //last char is =
        padding = 1;

    return (len*3)/4 - padding;
}

int Base64Decode(char* b64message, unsigned char** buffer, size_t* length) { //Decodes a base64 encoded string
    BIO *bio, *b64;

    int decodeLen = calcDecodeLength(b64message);
    *buffer = (unsigned char*)malloc(decodeLen + 1);
    (*buffer)[decodeLen] = '\0';

    bio = BIO_new_mem_buf(b64message, -1);
    b64 = BIO_new(BIO_f_base64());
    bio = BIO_push(b64, bio);

    BIO_set_flags(bio, BIO_FLAGS_BASE64_NO_NL); //Do not use newlines to flush buffer
    *length = BIO_read(bio, *buffer, strlen(b64message));
    assert(*length == decodeLen); //length should equal decodeLen, else something went horribly wrong
    BIO_free_all(bio);

    return (0); //success
}

int myencrypt(char *plaintext, unsigned char *key, unsigned char *iv, char ciphertext_base64[]){
    unsigned char ciphertext[1024];

    int ciphertext_len;
    ciphertext_len = CBCencrypt(plaintext, strlen ((char *)plaintext), key, iv, ciphertext);

    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);
    
    strcpy(ciphertext_base64,ciphertext_base);

    // returns original ciphertext length
    return ciphertext_len;
}

void mydecrypt(char * ciphertext_base64, unsigned char *key, unsigned char *iv, int length, unsigned char decryptedtext[]){
    
    unsigned char* base64DecodeOutput;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeOutput, &test);

    int decryptedtext_len;
    decryptedtext_len = CBCdecrypt(base64DecodeOutput, length, key, iv,
                                decryptedtext);

    decryptedtext[decryptedtext_len] = '\0';
}

int myencrypt2(char *plaintext, unsigned char *key, unsigned char *iv, char ciphertext_base64[]){
    unsigned char ciphertext[1024];

    int ciphertext_len;
    ciphertext_len = CBCencrypt2(plaintext, strlen((char *)plaintext), key, iv, ciphertext);
    
    char *ciphertext_base;
    Base64Encode(ciphertext, ciphertext_len, &ciphertext_base);

    // char *tag_base;
    // Base64Encode(tag, 14, &tag_base);

    strcpy(ciphertext_base64,ciphertext_base);
    // strcpy(tag_base64, tag_base);
    // returns original ciphertext length
    return ciphertext_len;
}

void mydecrypt2(char *ciphertext_base64, unsigned char *key, unsigned char *iv, int length, unsigned char decryptedtext[]){
    
    unsigned char* base64DecodeCipher;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeCipher, &test);

    // unsigned char* base64DecodeTag;
    // Base64Decode(tag_base64, &base64DecodeTag, &test);

    int decryptedtext_len;
    // printf("length is %d\n", length);
    // decryptedtext_len = CCMdecrypt(base64DecodeCipher, length, base64DecodeTag, key, iv,
    //                             decryptedtext);
    decryptedtext_len = CBCdecrypt2(base64DecodeCipher, length, key, iv, decryptedtext);
    // printf("CCMdecrypt successful, len = %d\n", decryptedtext_len);

    decryptedtext[decryptedtext_len] = '\0';
    return;
}


void serverRSAkeyPairGen(char base64_pub[]) {

    // size_t pri_len;            // Length of private key
    size_t pub_len;            // Length of public key
    // char   *pri_key;           // Private key
    char   *pub_key;

    struct stat st = {0};

    if(stat("serverkeys", &st) == -1) {
        mkdir("serverkeys", 0700);
    }

    char pubFile[1024], privFile[1024];
    sprintf(pubFile, "serverkeys/serverpub.txt");
    sprintf(privFile, "serverkeys/serverpriv.txt");

    FILE* fp1 = fopen(pubFile, "w");
    FILE* fp2 = fopen(privFile, "w");

    RSA *keypair = RSA_generate_key(KEY_LEN, PUB_EXP, NULL, NULL);

    PEM_write_RSAPublicKey(fp1, keypair);
    PEM_write_RSAPrivateKey(fp2, keypair, NULL, NULL, 0, NULL, NULL);

    fflush(fp1);
    fflush(fp2);

    fclose(fp1);
    fclose(fp2);

    BIO *pub = BIO_new(BIO_s_mem());
    PEM_write_bio_RSAPublicKey(pub, keypair);
    pub_len = BIO_pending(pub);
    pub_key = malloc(pub_len + 1);
    BIO_read(pub, pub_key, pub_len);
    pub_key[pub_len] = '\0';

    strcpy(base64_pub, pub_key);
    printf("server public and private keys are generated\n");

    return;
}

void server_privkey_decrypt(char* ciphertext_base64, char dec_msg[], int length) {
	RSA *rsa = NULL;

	char privFile[1024];
    sprintf(privFile, "serverkeys/serverpriv.txt");

    FILE* fp = fopen(privFile, "r");
    
    rsa = PEM_read_RSAPrivateKey(fp, &rsa, NULL, NULL);
    fclose(fp);

    unsigned char* base64DecodeOutput;
    size_t test;
    Base64Decode(ciphertext_base64, &base64DecodeOutput, &test);
    
    int decrypted_len;
    decrypted_len = RSA_private_decrypt(length, (unsigned char*)base64DecodeOutput, (unsigned char*)dec_msg, rsa, RSA_PKCS1_OAEP_PADDING);
    
    dec_msg[decrypted_len] = '\0';
	
	return;
}

void userPasswordGen() {
    struct stat st = {0};

    if(stat("UserCredentials", &st) == -1) {
        mkdir("UserCredentials", 0700);
    }

    char users[MAX][100];
    FILE *fp1 = fopen("users.txt", "r");
    int i = 0;
    char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    srand(time(0));
    while(fscanf(fp1, "%s", users[i]) != EOF) {
        
        char fileName[MAX];
        strcpy(fileName, "UserCredentials/");
        strcat(fileName, users[i]);
        strcat(fileName, ".txt");

        FILE *fp2 = fopen(fileName, "w");

        char salt[17];
        
        for(int j = 0; j < 8; j++) {
            salt[j] = charset[rand() % 62];
            salt[8+j] = '0';
        }
        salt[16] = '\0';
        
        char *base64_salt;
        Base64Encode(salt, 17, &base64_salt);
        base64_salt[24] = '\0';

        char zeroStr[17];
        for(int j = 0; j < 16;j++) {
            zeroStr[j] = '0';
        }
        zeroStr[16] = '\0';
        
        char chipher_base64[MAX], dec_msg2[MAX];
        int a = myencrypt(zeroStr, passwords[i], salt, chipher_base64);
        chipher_base64[44] = '\0';

        char len[10];
        sprintf(len, "%d", a);

        char temp[MAX];
        strcpy(temp, chipher_base64);
        strcat(temp, "|");
        strcat(temp, len);

        fprintf(fp2, "%s\n", users[i]);
        fprintf(fp2, "%s\n", base64_salt);
        fprintf(fp2, "%s\n", temp);
        
        fclose(fp2);
        
        i++;
    }

    fclose(fp1);
    return;

}

void list_files(char files[]) {
    DIR* dr;
    struct dirent* de;
    
    dr = opendir(".");
    if(dr == NULL) {
        // printf("ERROR!! Couldn't open current directory\n");
        strcpy(files, "ERROR|");
        return;
    }
    char buff[1024] = "|";
    
    while((de = readdir(dr)) != NULL) {
        if(strcmp(de->d_name, ".") != 0 && strcmp(de->d_name, "..") != 0) {
            strcat(buff, de->d_name);
            strcat(buff, "|");
        }
    }

    strcpy(files, buff);
    
    closedir(dr);

    return;

}

void getWorkDir(char dir[]) {
    char currWorkDir[1024];
    if(getcwd(currWorkDir, 1024) == NULL) {
        strcpy(dir, "ERROR|");
        return;
    }
    
    strcpy(dir, currWorkDir);
    strcat(dir, "|");

    return;
}

int changeWorkDir(char newDir[]) {
    
    char buff[1024];

    int flag = chdir(newDir);
    
    if(flag == -1) {
        // printf("Given directory doesn't exist\n");
        return 0;
    }
    
    // printf("Current directory changed\n");
    return 1;
}

int copyfile(char filename[], char src[], char dest[]) {
    
    char temp[1024];
    strcpy(temp, src);
    strcat(temp, "/");
    strcat(temp, filename);

    FILE* fp = fopen(temp, "r");
    if(fp == NULL) {
        // printf("ERROR!! No such file exist in given src directory\n");
        return 0;
    }

    char* content;
    int content_len;
    if(fp) {
        fseek (fp, 0, SEEK_END);
        content_len = ftell (fp);
        fseek (fp, 0, SEEK_SET);
        content = (char*)malloc(content_len+1);
        if(content) {
            fread(content, 1, content_len, fp);
        }
        fclose(fp);    
    }
    content[content_len] = '\0';

    char newFile[MAX];
    strcpy(newFile, dest);
    strcat(newFile, "/");
    strcat(newFile, filename);

    fp = fopen(newFile, "w");
    fprintf(fp, "%s", content);
    fclose(fp);

    return 1;
}

int movefile(char filename[], char src[], char dest[]) {
    
    if(copyfile(filename, src, dest) == 0) {
        return 0;
    }

    char temp[1024];
    strcpy(temp, src);
    strcat(temp, "/");
    strcat(temp, filename);

    remove(temp);

    return 1;
}

void connectClient(char base64_pub[], int port) {

    int socket_id, newSocket;
    char buffer[4098];
    struct sockaddr_in servaddr;
    struct sockaddr_storage serverStorage;
    socklen_t addr_size;

    socket_id = socket(AF_INET, SOCK_STREAM, 0);

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(port);
    memset(servaddr.sin_zero, '\0', sizeof servaddr.sin_zero);

    bind(socket_id, (struct sockaddr *) &servaddr, sizeof(servaddr));
    listen(socket_id, 5);
    printf("Server listening...\n");

    addr_size = sizeof serverStorage;
    newSocket = accept(socket_id, (struct sockaddr *)&serverStorage, &addr_size);
    printf("Client found...\n");

    strcpy(buffer, base64_pub);
    printf("Initiating authentication process...\n");
    write(newSocket, buffer, 4098);
    
    read(newSocket, buffer, 4098);
    // printf("buffer is :%s\n", buffer);
    char *r1[2]; // r1[0] has base64_enc and r1[1] is length
    char * token = strtok(buffer, "|");
    int i = 0;
    while( token != NULL ) {
        r1[i++] = token;
        token = strtok(NULL, "|");
    }

    char temp[4098];
    // printf("r1[0] is %s\n", r1[0]); // it contains username, password and session key
    server_privkey_decrypt(r1[0], temp, atoi(r1[1]));
    // printf("temp :%s\n", temp);
    char *r2[3];  // r2[0] = username, r2[1] = password, r2[2] = session key
    char * token2 = strtok(temp, "|");
    i = 0;
    while( token2 != NULL ) {
        r2[i++] = token2;
        token2 = strtok(NULL, "|");
    }

    char passFile[1024];
    strcpy(passFile, "UserCredentials/");
    strcat(passFile, r2[0]);
    strcat(passFile, ".txt");
    
    FILE* fp = fopen(passFile, "r");
    
    char user[9], base64_iv[MAX], temp2[MAX]; // temp2 contains ciphertext of all zeros string and length
    fscanf(fp, "%s", user);
    fscanf(fp, "%s", base64_iv);
    fscanf(fp, "%s", temp2);

    unsigned char *IV;
    size_t test;
    Base64Decode(base64_iv, &IV, &test);
    
    char *r3[2];  // r3[0] = encryption of all zero string with IV and password r3[1] is length
    char * token3 = strtok(temp2, "|");
    i = 0;
    while( token3 != NULL ) {
        r3[i++] = token3;
        token3 = strtok(NULL, "|");
    }

    char decrypted_text[1024];
    
    mydecrypt(r3[0], r2[1], IV, atoi(r3[1]), decrypted_text);
    if(strcmp(decrypted_text, "0000000000000000") == 0) {
        printf("Authentication successful\n");
        strcpy(buffer, "OK");
    }
    else {
        printf("Authentication failed\n");
        strcpy(buffer, "NOK");
    }

    write(newSocket, buffer, 4098);

    printf("Access granted...\n");
    int flag = 0;
    while(1) {

        read(newSocket, buffer, 4098);
        // printf("buffer is :%s\n", buffer);
        
        char *r22[2];  
        char * token2 = strtok(buffer, "|");
        i = 0;
        while( token2 != NULL ) {
            r22[i++] = token2;
            token2 = strtok(NULL, "|");
        }
        // printf("r22[0] = %s\n", r22[0]);
        // printf("r22[2] = %d\n", atoi(r22[2]));


        char dec_buff[4098];
        // printf("session key is :%s\n", r2[2]);
        mydecrypt2(r22[0], r2[2], "1234567890123456", atoi(r22[1]), dec_buff);
        // printf("dec buff is %s\n", dec_buff);
        // strcpy(dec_buff, buffer);
        char *r4[MAX];  
        char * token4 = strtok(dec_buff, "|");
        i = 0;
        while( token4 != NULL ) {
            r4[i++] = token4;
            token4 = strtok(NULL, "|");
        }

        // printf("r4[0] = %s\n", r4[0]);
        char m[4098];
        if(strcmp(r4[0], "LS") == 0) {
            char fileslist[1024];
            list_files(fileslist);
            
            strcpy(m, fileslist);
        }
        else if (strcmp(r4[0], "PWD") == 0) {
            char workDir[1024];
            getWorkDir(workDir);

            strcpy(m, workDir);
        }
        else if (strcmp(r4[0], "CD") == 0) {
            int flag = changeWorkDir(r4[1]);
            if(flag == 1) {
                strcpy(m, "Done|");
                // printf("Done\n");
            }
            else 
                strcpy(m, "ERROR|");
        }
        else if (strcmp(r4[0], "CP") == 0) {
            int flag = copyfile(r4[1], r4[2], r4[3]);
            if(flag == 1)
                strcpy(m, "Done|");
            else 
                strcpy(m, "ERROR|");
        }
        else if (strcmp(r4[0], "MV") == 0) {
            int flag = movefile(r4[1], r4[2], r4[3]);
            if(flag == 1)
                strcpy(m, "Done|");
            else 
                strcpy(m, "ERROR|");
        }
        else if(strcmp(r4[0], "EXIT") == 0) {
            printf("Server exiting...\n");
            flag = 1;
        }
        if(flag == 1) {
            return;
        }
        char cipher_base64[4098];
        int cipher_len = myencrypt2(m, r2[2], "1234567890123456", cipher_base64);

        char len[10];
        sprintf(len, "%d", cipher_len);

        strcpy(buffer, cipher_base64);
        // strcat(buffer, "|");
        // strcat(buffer, tag_base64);
        strcat(buffer, "|");
        strcat(buffer, len);
        // strcpy(buffer, m);
        // printf("new buffer is :%s\n", buffer);
        write(newSocket, buffer, 1024);
        // memset(buffer, '\0', 4098);
    }
    return;
}

int main(int argc, char* argv[]) {
    
    int port = atoi(argv[1]);

    char base64_pub[4098];
    serverRSAkeyPairGen(base64_pub);

    for(int i = 0; i < 10; i++) {
        strcpy(passwords[i], "1234567890123456");
        passwords[i][16] = '\0';
    }
    
    userPasswordGen();

    connectClient(base64_pub, port);
    
    return 0;
}