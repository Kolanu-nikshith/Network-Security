#include<bits/stdc++.h>
#include<chrono>
#include<unistd.h>
using namespace std;

const int ALPHABET_SIZE = 26;

class TrieNode {
public:
	bool isEnd;
	vector<TrieNode*>children;
	TrieNode() {
		isEnd = false;
		children.resize(ALPHABET_SIZE, NULL);
	}
};

TrieNode* create_node() {
	TrieNode* temp = new TrieNode();
	return temp;
}

void insert(TrieNode* root, string key) {
	TrieNode* temp = root;
	for(int i = 0; i < key.length(); i++) 
	{
		int index = key[i] - 'a';
		if(!temp->children[index])
			temp -> children[index] = create_node();

		temp = temp -> children[index];

	}

	temp -> isEnd = true;
}

bool search(TrieNode *root, string key) 
{ 
    TrieNode *temp = root; 
  
    for (int i = 0; i < key.length(); i++) 
    { 
        int index = key[i] - 'A'; 
        if (!temp->children[index]) 
            return false; 
  
        temp = temp->children[index]; 
    } 
  
    return (temp != NULL && temp->isEnd); 
}

string decrypt(string cipher, vector<int>key) {

	string plain = "";
	for(int i = 0; i < cipher.length(); i++) {
		char p = 'A' + ((cipher[i] - 'A' - key[i] + 26) % 26);
		plain += p; 
	}
	
	return plain;
}

void convert(int i, vector<int>& key) {

	int j = 7;
	while(j >= 0) {
		key[j] = (i%10)+1;
		i = i/10;
		j--;
	}
}
 
int main() {

	TrieNode* root = create_node();

	fstream file, file2;
	string word, plain, filename = "dictionary.txt";
	file.open(filename.c_str());

	while(file >> word) {
		insert(root, word);
	}

	filename = "bruteForceCiphertext.txt";
	file2.open(filename.c_str());

	vector<string>ciphertext;
	
	while(file2 >> word) {
		ciphertext.push_back(word);
	}
	
	vector<int>key(8);
	
	auto start = chrono::steady_clock::now();

	for(int j = 0; j < pow(10, 8); j++) {
		
		convert(j, key);
		
		vector<string> plaintext;

		for(int i = 0; i < ciphertext.size(); i++) {
			plain = decrypt(ciphertext[i], key);
			plaintext.push_back(plain);
		}
		
		bool flag = 1;
		for(int i = 0; i < plaintext.size(); i++) {
			if(search(root, plaintext[i]) == false) {
				flag = 0;
				break;
			}
		}

		if(flag == 1) {

			auto end = chrono::steady_clock::now();

			cout << "Key : ";
			for(int i = 0; i < 8; i++) {
				cout << key[i] << " ";
			}
			cout << endl;
			for(int i = 0; i < plaintext.size(); i++) {
				cout << plaintext[i] << " ";	
			}
			cout << endl;

			cout << "Time elapsed in milli seconds : " << chrono::duration_cast<chrono::milliseconds>(end-start).count() << " ms" << endl;

			break;
		}

	}

	 
	return 0;
}
