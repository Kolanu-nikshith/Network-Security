#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include <openssl/conf.h>
#include <openssl/evp.h>
#include <openssl/err.h>
#include <openssl/des.h>

#define MAX_SIZE 204800

void handleErrors(void)
{
    ERR_print_errors_fp(stderr);
    abort();
}

int aes_ofb_encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key,
            unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(strlen(key) == 32) {
        if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_ofb(), NULL, key, iv))
            handleErrors();
    }
    else if(strlen(key) == 16) {
        if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_ofb(), NULL, key, iv))
            handleErrors();
    }
    
    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}


int aes_ofb_decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(strlen(key) == 32) {
        if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_ofb(), NULL, key, iv))
            handleErrors();
    }
    else if(strlen(key) == 16) {
        if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_128_ofb(), NULL, key, iv))
            handleErrors();
    }
    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int aes_ccm_encrypt(unsigned char *plaintext, int plaintext_len,
                // unsigned char *aad, int aad_len,
                unsigned char *key,
                unsigned char *iv,
                unsigned char *ciphertext,
                unsigned char *tag)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;


    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /* Initialise the encryption operation. */
    if(strlen(key) == 32) {
        if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_ccm(), NULL, NULL, NULL))
            handleErrors();
    }

    else if(strlen(key) == 16) {
        if(1 != EVP_EncryptInit_ex(ctx, EVP_aes_128_ccm(), NULL, NULL, NULL))
            handleErrors();
    }
    

    /*
     * Setting IV len to 7. Not strictly necessary as this is the default
     * but shown here for the purposes of this example.
     */
    // if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_IVLEN, 7, NULL))
    //     handleErrors();

    /* Set tag length */
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_TAG, 14, NULL);

    /* Initialise key and IV */
    if(1 != EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv))
        handleErrors();

    /* Provide the total plaintext length */
    if(1 != EVP_EncryptUpdate(ctx, NULL, &len, NULL, plaintext_len))
        handleErrors();

    /* Provide any AAD data. This can be called zero or one times as required */
    // if(1 != EVP_EncryptUpdate(ctx, NULL, &len, aad, aad_len))
    //     handleErrors();

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can only be called once for this.
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Normally ciphertext bytes may be written at
     * this stage, but this does not occur in CCM mode.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Get the tag */
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_GET_TAG, 14, tag))
        handleErrors();

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int aes_ccm_decrypt(unsigned char *ciphertext, int ciphertext_len,
                // unsigned char *aad, int aad_len,
                unsigned char *tag,
                unsigned char *key,
                unsigned char *iv,
                unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int plaintext_len;
    int ret;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /* Initialise the decryption operation. */
    if(strlen(key) == 32) {
        if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_256_ccm(), NULL, NULL, NULL))
            handleErrors();
    }
    else if(strlen(key) == 16) {
        if(1 != EVP_DecryptInit_ex(ctx, EVP_aes_128_ccm(), NULL, NULL, NULL))
        handleErrors();
    }
    
    /* Setting IV len to 7. Not strictly necessary as this is the default
     * but shown here for the purposes of this example */
    // if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_IVLEN, 7, NULL))
    //     handleErrors();

    /* Set expected tag value. */
    if(1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_CCM_SET_TAG, 14, tag))
        handleErrors();

    /* Initialise key and IV */
    if(1 != EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv))
        handleErrors();


    /* Provide the total ciphertext length */
    if(1 != EVP_DecryptUpdate(ctx, NULL, &len, NULL, ciphertext_len))
        handleErrors();

    /* Provide any AAD data. This can be called zero or more times as required */
    // if(1 != EVP_DecryptUpdate(ctx, NULL, &len, aad, aad_len))
    //     handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary
     */
    ret = EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len);

    plaintext_len = len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    if(ret > 0) {
        /* Success */
        return plaintext_len;
    } else {
        /* Verify failed */
        return -1;
    }
}

int des_encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key,
            unsigned char *iv, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(1 != EVP_EncryptInit_ex(ctx, EVP_des_ede3_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
        handleErrors();
    ciphertext_len = len;

    /*
     * Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
        handleErrors();
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int des_decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key,
            unsigned char *iv, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;

    int len;

    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
        handleErrors();

    /*
     * Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits
     */
    if(1 != EVP_DecryptInit_ex(ctx, EVP_des_ede3_cbc(), NULL, key, iv))
        handleErrors();

    /*
     * Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary.
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
        handleErrors();
    plaintext_len = len;

    /*
     * Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
        handleErrors();
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int main(int argc, unsigned char* argv[]) {
    unsigned char *oper = argv[2];
    unsigned char *alg = argv[4];
    unsigned char *mode = argv[6];
    unsigned char *inpFile = argv[10];
    unsigned char *outFile = argv[12];
    int keysize = atoi(argv[8]);

    printf("%s\t%s\t%s\t%d\n", oper, alg, mode, keysize);

    if( (strcmp(alg, "AES") == 0) && (strcmp(mode, "CCM") == 0) ) {
        unsigned char *key;
        if(keysize == 128) {
            key = (unsigned char*)malloc(16*sizeof(unsigned char));
        }
        else if(keysize == 256) {
            key = (unsigned char*)malloc(32*sizeof(unsigned char));
        }
        unsigned char iv[7];
        printf("enter key : ");
        scanf("%s", key);
        printf("enter iv (7 bytes) : ");
        scanf("%s", iv);

        if(strcmp(oper, "Enc") == 0) {
            FILE *inp, *out, *tagptr;

            unsigned char tag[14], *plain, cipher[MAX_SIZE], decrypted[MAX_SIZE], encoded_cipher[MAX_SIZE], encoded_tag[MAX_SIZE];
            int cipher_len, decrypted_len, plain_len;

            inp = fopen(inpFile, "r");
            if(inp) {
                fseek (inp, 0, SEEK_END);
                plain_len = ftell (inp);
                fseek (inp, 0, SEEK_SET);
                plain = (char*)malloc(plain_len);
                if(plain) {
                    fread(plain, 1, plain_len, inp);
                }
                fclose(inp);    
            }
            
			clock_t t;
			t = clock();
            cipher_len = aes_ccm_encrypt(plain, plain_len, key, iv, cipher, tag);
            t = clock() - t;
            double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
    		printf("encryption took %f seconds \n", time_taken); 
    		double avg_time = time_taken/(1.0*1600);
    		printf("Mean block encryption time is %f seconds \n", avg_time); 
            // printf("cipher len = %d\n", cipher_len);

            out = fopen(outFile, "w");
            // int temp = EVP_EncodeBlock((unsigned char*)encoded_cipher, cipher, cipher_len);
            // printf("%s\n", encoded_cipher);
            // printf("length = %d\n", temp);

            // fprintf(out, "%s", encoded_cipher);

            for(int i = 0; i < cipher_len; i++) {
                fprintf(out, "%c", cipher[i]);
            }
            fclose(out);

            tagptr = fopen("test_tag.txt", "w");
            // EVP_EncodeBlock((unsigned char*)encoded_tag, tag, 14);
            // printf("%s\n", encoded_tag);
            // BIO_dump_fp(stdout, (const char *)tag, 14);
            // fprintf(tagptr, "%s", tag);
            for(int i = 0; i < 14; i++) {
                fprintf(tagptr, "%c", tag[i]);
            }
            fclose(tagptr);
            
        }

        else if(strcmp(oper, "Dec") == 0) {
            FILE *inp, *out, *tagptr;

            unsigned char tag[14], decrypted[MAX_SIZE], *cipher, encoded_tag[MAX_SIZE], *encoded_cipher;
            int encoded_cipher_len, cipher_len, decrypted_len;

            inp = fopen(inpFile, "r");
            if(inp) {
                fseek (inp, 0, SEEK_END);
                cipher_len = ftell (inp);
                fseek (inp, 0, SEEK_SET);
                cipher = (char*)malloc(cipher_len);
                if(cipher) {
                    fread(cipher, 1, cipher_len, inp);
                }

                // printf("%s\n", encoded_cipher);
                // printf("%d\n", encoded_cipher_len);
                // cipher_len = EVP_DecodeBlock((unsigned char*)cipher, encoded_cipher, encoded_cipher_len);

                fclose(inp);    
            }

            // printf("cipher len = %d\n", cipher_len);

            tagptr = fopen("test_tag.txt", "r");
            // fscanf(tagptr, "%s", tag);
            for(int i = 0; i < 14; i++) {
                fscanf(tagptr, "%c", &tag[i]);
            }
            // BIO_dump_fp(stdout, (const char *)tag, 14);
            // printf("tag : %s\n", encoded_tag);
            fclose(tagptr);

            // int temp = EVP_DecodeBlock((unsigned char*)tag, encoded_tag, strlen(encoded_tag));
            // printf("temp : %d\n", temp);
            
            clock_t t;
			t = clock();
            decrypted_len = aes_ccm_decrypt(cipher, cipher_len, tag, key, iv, decrypted);
            t = clock() - t;
            double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
            
            if(decrypted_len == -1) {
                puts("key or tag error");
            }
            else {
            	printf("decryption took %f seconds \n", time_taken);
            	double avg_time = time_taken/(1.0*1600);
    			printf("Mean block decryption time is %f seconds \n", avg_time); 
             
                decrypted[decrypted_len] = '\0';
                
                out = fopen(outFile, "w");
                fprintf(out, "%s", decrypted);
                fclose(out);
            }

        }
    }
    else if( (strcmp(alg, "AES") == 0) && (strcmp(mode, "OFB") == 0) ) {
        unsigned char iv[16];
        unsigned char *key;
        
        if(keysize == 128) {
            key = (unsigned char*)malloc(16*sizeof(unsigned char));
        }
        else if(keysize == 256) {
            key = (unsigned char*)malloc(32*sizeof(unsigned char));
        }
        
        printf("Enter key : ");
        scanf("%s", key);
        printf("Enter iv (16 bytes) : ");
        scanf("%s", iv);
        
        if(strcmp(oper, "Enc") == 0) {
            FILE *inp, *out;

            unsigned char *plain, cipher[MAX_SIZE], decrypted[MAX_SIZE];
            int plain_len, cipher_len, decrypted_len;
            
            inp = fopen(inpFile, "r");
            if(inp) {
                fseek (inp, 0, SEEK_END);
                plain_len = ftell (inp);
                fseek (inp, 0, SEEK_SET);
                plain = (char*)malloc(plain_len);
                if(plain) {
                    fread(plain, 1, plain_len, inp);
                }
                fclose(inp);    
            }
			clock_t t;
			t = clock();
            cipher_len = aes_ofb_encrypt (plain, plain_len, key, iv, cipher);
            t = clock() - t;
            double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
            printf("encryption took %f seconds \n", time_taken); 
            double avg_time = time_taken/(1.0*1600);
    		printf("Mean block encryption time is %f seconds \n", avg_time); 
            
            out = fopen(outFile, "w");
            for(int i = 0; i < cipher_len; i++) {
                fprintf(out, "%c", cipher[i]);
            }
            fclose(out);

        }

        else if(strcmp(oper, "Dec") == 0) {
            FILE *inp, *out;

            unsigned char *cipher, decrypted[MAX_SIZE];
            int cipher_len, decrypted_len;

            inp = fopen(inpFile, "r");
            if(inp) {
                fseek (inp, 0, SEEK_END);
                cipher_len = ftell (inp);
                fseek (inp, 0, SEEK_SET);
                cipher = (char*)malloc(cipher_len);
                if(cipher) {
                    fread(cipher, 1, cipher_len, inp);
                }
                fclose(inp);    
            }
			clock_t t;
			t = clock();
            decrypted_len = aes_ofb_decrypt(cipher, cipher_len, key, iv, decrypted);
			t = clock() - t;
            double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
            printf("decryption took %f seconds \n", time_taken); 
            double avg_time = time_taken/(1.0*1600);
    		printf("Mean block decryption time is %f seconds \n", avg_time); 
            
            decrypted[decrypted_len] = '\0';

            out = fopen(outFile, "w");
            fprintf(out, "%s", decrypted);
            fclose(out);
    
        }
        
    }

    else if( (strcmp(alg, "3DES") == 0) && (strcmp(mode, "CBC") == 0) ) {
        char iv[8];
        char key[24];

        printf("Enter key (24 bytes): ");
        scanf("%s", key);
        printf("Enter iv (8 bytes) : ");
        scanf("%s", iv);

        if(strcmp(oper, "Enc") == 0) {
            FILE *inp, *out;

            unsigned char *plain, cipher[MAX_SIZE], decrypted[MAX_SIZE];
            int plain_len, cipher_len, decrypted_len;
            
            inp = fopen(inpFile, "r");
            if(inp) {
                fseek (inp, 0, SEEK_END);
                plain_len = ftell (inp);
                fseek (inp, 0, SEEK_SET);
                plain = (char*)malloc(plain_len);
                if(plain) {
                    fread(plain, 1, plain_len, inp);
                }
                fclose(inp);    
            }

			clock_t t;
			t = clock();
            cipher_len = des_encrypt (plain, plain_len, key, iv, cipher);
            t = clock() - t;
            double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
            printf("encryption took %f seconds \n", time_taken); 
            double avg_time = time_taken/(1.0*1600);
    		printf("Mean block encryption time is %f seconds \n", avg_time); 
            
            out = fopen(outFile, "w");
            for(int i = 0; i < cipher_len; i++) {
                fprintf(out, "%c", cipher[i]);
            }
            fclose(out);
        }

        else if(strcmp(oper, "Dec") == 0) {
            FILE *inp, *out;

            unsigned char *cipher, decrypted[MAX_SIZE];
            int cipher_len, decrypted_len;

            inp = fopen(inpFile, "r");
            if(inp) {
                fseek (inp, 0, SEEK_END);
                cipher_len = ftell (inp);
                fseek (inp, 0, SEEK_SET);
                cipher = (char*)malloc(cipher_len);
                if(cipher) {
                    fread(cipher, 1, cipher_len, inp);
                }
                fclose(inp);    
            }
            
			clock_t t;
			t = clock();
            decrypted_len = des_decrypt(cipher, cipher_len, key, iv, decrypted);
			t = clock() - t;
            double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
            printf("decryption took %f seconds \n", time_taken); 
            double avg_time = time_taken/(1.0*1600);
    		printf("Mean block decryption time is %f seconds \n", avg_time); 
            
            decrypted[decrypted_len] = '\0';

            out = fopen(outFile, "w");
            fprintf(out, "%s", decrypted);
            fclose(out);
        }
    }
    
    return 0;
}
